#include "TorusCollisionShape.h"


TorusCollisionShape::TorusCollisionShape()
{
}


TorusCollisionShape::~TorusCollisionShape()
{
}
