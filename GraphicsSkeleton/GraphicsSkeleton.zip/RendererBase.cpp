#include "RendererBase.h"


RendererBase::RendererBase()
{
}


RendererBase::~RendererBase()
{
}
