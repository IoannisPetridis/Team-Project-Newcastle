#include "PS4SoundEmitter.h"


PS4SoundEmitter::PS4SoundEmitter()
{
}


PS4SoundEmitter::~PS4SoundEmitter()
{
}
