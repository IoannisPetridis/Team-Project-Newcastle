#include "ShaderBase.h"


ShaderBase::ShaderBase()
{
}


ShaderBase::~ShaderBase()
{
}
