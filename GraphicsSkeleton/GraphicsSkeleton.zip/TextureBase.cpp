#include "TextureBase.h"

TextureBase::TextureBase()
{
	width	= 0;
	height	= 0;
	bpp		= 0;
}

TextureBase::~TextureBase()
{
}
