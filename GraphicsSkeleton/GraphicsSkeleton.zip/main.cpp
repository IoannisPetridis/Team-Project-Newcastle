#include "ExampleRenderer.h"
#include "PS4Input.h"

#include <iostream>

int main(void) {
	ExampleRenderer renderer;


	PS4Input input = PS4Input();

	while (true) {
		input.Poll();
		renderer.UpdateScene(1.0f);
		renderer.RenderScene();
		renderer.SwapBuffers();


		if (input.GetButton(0)) {
			std::cout << "LOL BUTTON" << std::endl;
		}

		if (input.GetButton(1)) {
			return 1;
		}
	}

	return 1;
}