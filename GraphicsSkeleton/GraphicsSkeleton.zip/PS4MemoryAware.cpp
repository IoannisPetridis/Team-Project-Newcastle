#include "PS4MemoryAware.h"

sce::Gnmx::Toolkit::IAllocator		PS4MemoryAware::onionAllocator;
sce::Gnmx::Toolkit::IAllocator		PS4MemoryAware::garlicAllocator;
sce::Gnm::OwnerHandle				PS4MemoryAware::ownerHandle;
