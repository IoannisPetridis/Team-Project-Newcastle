#pragma once
class PS4ComputeShader
{
public:
	PS4ComputeShader();
	~PS4ComputeShader();
};

