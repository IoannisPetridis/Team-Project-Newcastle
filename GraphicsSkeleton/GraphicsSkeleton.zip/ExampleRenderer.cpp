#include "ExampleRenderer.h"

ExampleRenderer::ExampleRenderer()
{
}

ExampleRenderer::~ExampleRenderer()
{
}
